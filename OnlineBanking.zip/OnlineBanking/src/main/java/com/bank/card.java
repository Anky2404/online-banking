package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/card")
public class card extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		res.setContentType("text/html");
		PrintWriter prnt=res.getWriter();
		
		String ac_no=req.getParameter("acc_no");
		String pass=req.getParameter("pass");
		String card_type=req.getParameter("c_type");
		
		Date d=new Date();
		int yr=d.getYear();
		
		int yrs=yr-95;
		String exp="11/"+yrs;
		
		
		
		
		
		
		long atm=  (long) Math.abs((Math.random()*9999999999999000L)+999900000);
		
		int pin=(int) (Math.random()*9999);
		int cvv=(int) (Math.random()*999);
		
		if(Validate.checkUser(ac_no,pass))
		{
		String name = null;
		try 
		{
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt=con.prepareStatement("select*from transaction where ac_no= ?");
			
			psmt.setString(1,ac_no);
			
			
			ResultSet rs=psmt.executeQuery();
			
			
			while(rs.next())
			{
				 name=rs.getString("user");
				
				
			}
			
			
			
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt1=con1.prepareStatement("insert into card(ac_no,user,atm,pin,c_type,cvv,exp) values(?,?,?,?,?,?,?)");
			psmt1.setString(1,ac_no);
			psmt1.setString(2,name);
			psmt1.setLong(3,atm);
			psmt1.setInt(4,pin);
			psmt1.setString(5,card_type);
			psmt1.setLong(6,cvv);
			psmt1.setString(7,exp);
			
			int i=psmt1.executeUpdate();
			
			if(i>0)
			{
				prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
				prnt.println("<div>");
				prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
				
				prnt.println("Account Holder's Name : "+name+"<br><br>");
				prnt.println("Account Number : "+ac_no+"<br><br>");
				prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
				prnt.println("ATM Number : "+atm+"<br><br>");
				prnt.println("PIN Code : "+pin+"<br><br>");
				prnt.println("Card Type : "+card_type+"<br><br>");
				prnt.println("Branch's Name : Rohini Branch<br><br>");
				prnt.println("ATM CVV Number : "+cvv+"<br><br>");
				prnt.println("Card Expiry Date : "+exp+"<br><br><br><br>");
				
				prnt.println("<h2>ATM Applied Successfully....</h2"+"<br><br>");
				prnt.println("<h2>Thank You....</h2>"+"<br><br>");				
				prnt.println("</div>");
				prnt.println("</body></html>");
				
			}
			else
			{
				prnt.println("Registration not successed...");
			}
		
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
			prnt.println("<div>");
			prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
			
			prnt.println("Account Holder's Name : "+name+"<br><br>");
			prnt.println("Account Number : "+ac_no+"<br><br>");
			prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
			prnt.println("Branch's Name : Rohini Branch<br><br>");
			prnt.println("<h2>ATM has been already applied...</h2"+"<br><br>");
			prnt.println("<h2>Thank You....</h2>"+"<br><br>");				
			prnt.println("</div>");
			prnt.println("</body></html>");
			
		}
		}
		else
		{
			prnt.println("<html><head><style>body{width:100vw; height:100vh; background-color:red;}h1{color:blue;}</style></head><body>");
			prnt.println("<h1 c>Incorrect Username or password</h1>"); 
			prnt.println("</body></html>");
		}
		
		
		
		
		
	}

}
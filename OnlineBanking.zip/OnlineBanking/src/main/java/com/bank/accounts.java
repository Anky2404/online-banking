package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/acc")
public class accounts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		res.setContentType("text/html");
		PrintWriter prnt= res.getWriter();
		
		String ac_no= req.getParameter("acc_no");
		String pass=req.getParameter("pass");
		
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt=con.prepareStatement("select*from accounts where acc_no= ?");
			
			psmt.setString(1,ac_no);
			
			
			ResultSet rs=psmt.executeQuery();
			
			String name = null;
			String ac_type=null;
			String adhar=null;
			String atm=null;
			String pin=null;
			while(rs.next())
			{
				name=rs.getString("name");
				
				ac_type=rs.getString("ac_type");
				adhar=rs.getString("adhar");
				atm=rs.getString("atm");
				pin=rs.getString("pin");
			}
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt1=con.prepareStatement("select*from transaction where ac_no= ?");
			
			psmt1.setString(1,ac_no);
			
			
			ResultSet rs1=psmt1.executeQuery();
			int total=0;
			
			while(rs1.next())
			{
				
				String type=rs1.getString("trans_type");
				if(type.equals("Credited"))
				{
					total += rs1.getInt("amt");
				}
				else
				{
					total -= rs1.getInt("amt");
				}
				
			}
				
				
							
				
				prnt.println("<html><head><style>h2{color:green;}h1{color:blue;}div{margin-left:25vw;width:50vw;background-color:red;color:yellow; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
				prnt.println("<div>");
				prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
				prnt.println("Account Holder's Name : "+name+"<br><br>");
				prnt.println("Account Number : "+ac_no+"<br><br>");
				prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
				prnt.println("Branch's Name : Rohini Branch<br><br>");
				prnt.print("Adhar Number : "+adhar+"<br><br>");
				prnt.print("Atm Number : "+atm+"<br><br>");
				prnt.print("Atm Pin : "+pin+"<br><br>");
				prnt.print("Login Password : "+pass+"<br><br>");
				prnt.print("Account Type : "+ac_type+"<br><br>");
				prnt.print("Total Amount : "+total+"<br><br>");
				
				
				
				prnt.println("<h2>Thank You....</h2"+"<br><br>");
				
				prnt.println("</div>");
				prnt.println("</body></html>");
				
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}

package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/reg")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		res.setContentType("text/html");
		PrintWriter prnt=res.getWriter();
		
		
		
		String type=req.getParameter("ac_type");
		String name=req.getParameter("user");
		String adhar=req.getParameter("adhar");
		String pass=req.getParameter("pass");
		String t_type="Credited";
		int amnt=Integer.parseInt(req.getParameter("amt"));
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt=con.prepareStatement("insert into accounts(name,adhar,pass,amt,ac_type) values(?,?,?,?,?)");
			psmt.setString(1,name);
			psmt.setString(2,adhar);
			psmt.setString(3,pass);
			psmt.setInt(4,amnt);
			psmt.setString(5,type);
			int i=psmt.executeUpdate();
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt1=con1.prepareStatement("select*from accounts where name= ?");
			
			psmt1.setString(1,name);
			
			
			ResultSet rs=psmt1.executeQuery();
			String ac_no=null;
			while(rs.next())
			{
				 ac_no=rs.getString("acc_no");
				
			}
			
			
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt2=con2.prepareStatement("insert into transaction(user,ac_no,trans_type,amt) values(?,?,?,?)");
			psmt2.setString(1,name);
			psmt2.setString(2, ac_no);
			psmt2.setString(3, t_type);
			psmt2.setInt(4,amnt);
			
			int i1=psmt2.executeUpdate();
			
			
			if(i>0)
			{
				
				prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
				prnt.println("<div>");
				prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
				prnt.println("Account Holder's Name : "+name+"<br><br>");
				prnt.println("Account Number : "+ac_no+"<br><br>");
				prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
				prnt.println("Adhar Number : "+adhar+"<br><br>");
				prnt.println("Deposit Amount : "+amnt+"<br><br>");
				prnt.println("Branch's Name : Rohini Branch<br><br>");
				prnt.println("Account Type : "+type+"<br><br>");
				prnt.println("Login Password : "+pass+"<br><br><br><br>");
				
				prnt.println("<h2>Registration Successfully....</h2"+"<br><br>");
				prnt.println("<h2>Thank You....</h2>"+"<br><br>");				
				prnt.println("</div>");
				prnt.println("</body></html>");
			}
			else
			{
				prnt.println("Registration not successed...");
			}
		
		}
		catch (Exception e) {
			prnt.println("<html><head><style>body{width:100vw; height:100vh; background-color:red;}h1{color:blue;}</style></head><body>");
			prnt.println("<h1 c>Account already Existed....</h1>"); 
			prnt.println("</body></html>");
		}
		
		
		
		
	}

}

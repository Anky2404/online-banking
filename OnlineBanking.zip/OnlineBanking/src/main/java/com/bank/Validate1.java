package com.bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Validate1 
{
	public static boolean checkUser(String id,String pass)
	{
		boolean st=false;
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt=con.prepareStatement("select*from admin where u_id=? and pass=?");
			psmt.setString(1, id);
			psmt.setString(2, pass);
			
			ResultSet rs=psmt.executeQuery();
			st=rs.next();
		
		
		
		
		
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return st;
		}
}



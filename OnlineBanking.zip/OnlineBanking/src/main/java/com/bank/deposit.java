package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/dep")
public class deposit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		res.setContentType("text/html");
		PrintWriter prnt= res.getWriter();
		java.util.Date date=new java.util.Date();
		
		
		
		
		
		String name=req.getParameter("user");
		String ac_no=req.getParameter("acc_no");
		int d_amt=Integer.parseInt(req.getParameter("amt"));
		String t_type="Credited";
		
		
		
		
		
		try 
		{
			
		
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt1=con1.prepareStatement("insert into transaction(user,ac_no,trans_type,amt) values(?,?,?,?)");
			psmt1.setString(1,name);
			psmt1.setString(2,ac_no);
			psmt1.setString(3,t_type);
			psmt1.setInt(4,d_amt);
			
			
			
			
			
			
			
			
			int i=psmt1.executeUpdate();
			
			
			if(i>0)
			{
				prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
				prnt.println("<div>");
				prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
				prnt.println("Account Holder's Name : "+name+"<br><br>");
				prnt.println("Account Number : "+ac_no+"<br><br>");
				prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
				prnt.println("Branch's Name : Rohini Branch<br><br>");
				prnt.println("Deposit Amount : "+d_amt+"<br><br>");
				prnt.println("Trans. Date : "+date+"<br><br>");
				
				
				prnt.println("<h3>Transaction Successfully....</h3>"+"<br><br>");
				
				prnt.println("<h2>Thank You....</h2>"+"<br><br>");
				
				prnt.println("</div>");
				prnt.println("</body></html>");
				
				
				
			}
			else
			{
				prnt.println("Transaction Failed !....");
			}
		
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			}
		
	}



package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/close")
public class close extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		res.setContentType("text/html");
		PrintWriter prnt= res.getWriter();
		String id= req.getParameter("u_id");
		String ac_no= req.getParameter("acc_no");
		String pass=req.getParameter("pass");
		
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt=con.prepareStatement("select*from transaction where ac_no= ?");
			
			psmt.setString(1,ac_no);
			
			
			ResultSet rs=psmt.executeQuery();
			int total=0;
			String name = null;
			while(rs.next())
			{
				 name=rs.getString("user");
				String type=rs.getString("trans_type");
				if(type.equals("Credited"))
				{
					total += rs.getInt("amt");
				}
				else
				{
					total -= rs.getInt("amt");
				}
				
			}
			
			
			
			
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt1=con1.prepareStatement("delete from accounts where acc_no= ? and pass= ?");
			
			psmt1.setString(1,ac_no);
			psmt1.setString(2,pass);
			
			
			int i=psmt1.executeUpdate();
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt2=con2.prepareStatement("delete from transaction where ac_no= ?");
			
			psmt2.setString(1,ac_no);
			
			
			
			int i1=psmt2.executeUpdate();
			
													//Admin account delted
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con3=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt3=con3.prepareStatement("select*from admin where u_id= ? and pass= ?");
			
			psmt3.setString(1,id);
			psmt3.setString(2,pass);
			
			
			ResultSet rs1=psmt3.executeQuery();
			
			String admin = null;
			while(rs1.next())
			{
				 admin=rs1.getString("uname");
				
				
				
				
			}
			
			
			
			
			
			
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con4=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt4=con4.prepareStatement("delete from admin where u_id= ? and pass= ?");
			
			psmt4.setString(1,id);
			psmt4.setString(2,pass);
			
			
			int i3=psmt4.executeUpdate();
				
				if(i>0)
				{
					prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
					prnt.println("<div>");
					prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
					prnt.println("Account Holder's Name : "+name+"<br><br>");
					prnt.println("Account Number : "+ac_no+"<br><br>");
					prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
					prnt.println("Your Rest Amount : "+total+"<br><br><br><br>");
					prnt.println("Branch's Name : Rohini Branch<br><br>");
					
					prnt.println("<h2>User Account Deleted Successfully....</h2"+"<br><br>");
					prnt.println("<h2>Thank You....</h2>"+"<br><br>");				
					prnt.println("</div>");
					prnt.println("</body></html>");
				}
				
				else if(i1>0)
				{
					prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
					prnt.println("<div>");
					prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
					prnt.println("Account Holder's Name : "+name+"<br><br>");
					prnt.println("Account Number : "+ac_no+"<br><br>");
					prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
					prnt.println("Your Rest Amount : "+total+"<br><br><br><br>");
					prnt.println("Branch's Name : Rohini Branch<br><br>");
					
					prnt.println("<h2>User Account Deleted Successfully....</h2"+"<br><br>");
					prnt.println("<h2>Thank You....</h2>"+"<br><br>");				
					prnt.println("</div>");
					prnt.println("</body></html>");
				}
				else if(i3>0)
				{
					prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
					prnt.println("<div>");
					prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
					prnt.println("Admin Name : "+admin+"<br><br>");
					prnt.println("Admin Id : "+id+"<br><br>");
					prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
					
					prnt.println("Branch's Name : Rohini Branch<br><br>");
					
					prnt.println("<h2>Admin Account Deleted Successfully....</h2"+"<br><br>");
					prnt.println("<h2>Thank You....</h2>"+"<br><br>");				
					prnt.println("</div>");
					prnt.println("</body></html>");
				}
				else
				{
					prnt.println("Account not deleted");
				}
				
				
				
				
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}

package com.bank;

import java.io.IOException;
import java.io.PrintWriter;

import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/log")
public class Login extends HttpServlet 
{
	ResultSet cs;
	static Statement s;

	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		res.setContentType("text/html");
		PrintWriter prnt= res.getWriter();
		
		String ac_no= req.getParameter("acc_no");
		String pass= req.getParameter("pass");
		
		if(Validate.checkUser(ac_no,pass))
		{
			RequestDispatcher rs=req.getRequestDispatcher("Login.html");
			rs.forward(req, res);
		}
		else
		{
			
			prnt.println("<html><head><style>body{width:100vw; height:100vh; background-color:red;}h1{color:blue;}</style></head><body>");
			prnt.println("<h1 c>Incorrect Username or password</h1>"); 
			prnt.println("</body></html>");
			
		}
	}

}

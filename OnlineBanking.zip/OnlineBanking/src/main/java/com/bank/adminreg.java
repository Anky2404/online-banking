package com.bank;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/admin")
public class adminreg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		res.setContentType("text/html");
		PrintWriter prnt=res.getWriter();
		
		
		
		String id=req.getParameter("u_id");
		String name=req.getParameter("user");
		String adhar=req.getParameter("adhar");
		String pass=req.getParameter("pass");
		String type=req.getParameter("ac_type");
		
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/anky?autoReconnect=true&useSSL=false","root","Love@123");
			PreparedStatement psmt=con.prepareStatement("insert into admin(u_id,uname,adhar,pass,terms) values(?,?,?,?,?)");
			psmt.setString(1,id);
			psmt.setString(2,name);
			psmt.setString(3,adhar);
			psmt.setString(4,pass);
			psmt.setString(5,type);
			
			
			
			
			
			
			int i=psmt.executeUpdate();
			
			
			if(i>0)
			{
				
				prnt.println("<html><head><style>h2{color:green;}h1{color:yellow;}div{margin-left:25vw;width:50vw;background-color:red;color:blue; text-align:center; font-size:20px; border:10px groove blue;}</style></head><body>");
				prnt.println("<div>");
				prnt.println("<h1>Welcome To Lena Bank</h1>"+"<br><br>");
				prnt.println("Admin Name : "+name+"<br><br>");
				prnt.println("Admin User Id : "+id+"<br><br>");
				prnt.println("Ifsc Code : LBOI0002406"+"<br><br>");
				prnt.println("Adhar Number : "+adhar+"<br><br>");
				prnt.println("Branch's Name : Rohini Branch<br><br>");
				prnt.println("Login Password : "+pass+"<br><br><br><br>");
				
				prnt.println("<h2>Registration Successfully....</h2"+"<br><br>");
				prnt.println("<h2>Thank You....</h2>"+"<br><br>");				
				prnt.println("</div>");
				prnt.println("</body></html>");
			}
			else
			{
				prnt.println("Registration not successed...");
			}
		
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
